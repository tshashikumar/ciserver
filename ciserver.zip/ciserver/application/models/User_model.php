<?php
class User_model extends CI_Model {

        public function __construct()
        {
            parent::__construct();
        }
      /*  public function userSave($reqData){
            $response=$this->db->insert('user',$reqData);
            return $response;            
        }
        public function getUserList($userId=null){
            $this->db->select('*');
            $this->db->from('user');
            if($userId!=null):
                $this->db->where('id',$userId);
            endif;
            $this->db->order_by('id','DESC');
            $response=$this->db->get();
            return $response->result_array();
        }
        public function updateUser($userId){
            $this->db->where('id',$userId);
            $response=$this->db->update('user');
            return $response;
        }
        public function deleteUser($userId){
            $this->db->where('id',$userId);
            $response=$this->db->delete('user');
            return $response;
        }*/
}

?>