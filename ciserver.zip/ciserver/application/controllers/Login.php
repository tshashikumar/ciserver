<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Shashi kumar
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Login extends REST_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
    }
  
    public function users_get()
    {
        $this->response(['status'=>true,'data'=> $this->get('id')], REST_Controller::HTTP_CREATED);
        return $this->response;
    }
    public function users_delete(){
        //echo $this->delete('id');exit;
        $this->output->set_ouput($this->delete('id'));exit;
    }
	public function users_post(){

		$this->output->set_output(json_encode($this->post()));
	}
    public function users_put(){
       // print_r($this->put());exit;
        $this->output->set_output(json_encode($this->put()));
    }
 /*   public function users_post()
    {
        //print_r($this->input->post('gender'));exit;
        $requestData=array(
            'name' => $this->post('name'),
            'created_date' => $this->post('date'),
            'status' => $this->post('status'),
            'gender' => $this->post('gender')
        );
        $result=$this->User_model->userSave($requestData);
        if($result):
            $this->response(['status'=>true,'data'=> "Saved Sucuccessfully"], REST_Controller::HTTP_CREATED);
        else:
            $this->response(['status'=>false,'data'=> "Not Saved"]);
        endif;
        return $this->response;
    }
    public function userslist_post(){
        $this->load->library('form_validation');
        $id=($this->post('id')=="")? null:$this->post('id');
        $data=array('id'=>$id);
        if($id!=null):
            $this->form_validation->set_data($data);
            $this->form_validation->set_rules('id', 'User Id', 'trim|numeric');
            if ($this->form_validation->run() == FALSE):
                $this->response(['status'=>false,'data'=> "User Id Numeric"], REST_Controller::HTTP_BAD_REQUEST);
            else:
                
                $result=$this->User_model->getUserList($data['id']);
                if($result):
                    $this->response(['status'=>true,'data'=> $result], REST_Controller::HTTP_CREATED);
                else:
                    $this->response(['status'=>false,'message'=> "No data Found"], REST_Controller::HTTP_CREATED);
                endif;
            endif;
        else:
            $result=$this->User_model->getUserList();
            if($result):
                $this->response(['status'=>true,'data'=> $result], REST_Controller::HTTP_CREATED);
            else:
                $this->response(['status'=>false,'message'=> "No data Found"], REST_Controller::HTTP_CREATED);
            endif;
          //  $this->response(['status'=>false,'data'=> "Invalide Id"], REST_Controller::HTTP_BAD_REQUEST);
        endif; 
        return print_r(json_encode($this->response));
    }
    public function users_delete()
    {
        $result=$this->User_model->deleteUser(intval($this->delete('id')));
        if($result):
            $this->response(['status'=>true,'data'=> intval($this->delete('id')),'message' => 'User Deleted Successfully'], REST_Controller::HTTP_CREATED);
        else:
            $this->response(['status'=>true,'data'=> intval($this->delete('id')),'message' => 'User Delete Failed'], REST_Controller::HTTP_CREATED);
        endif;
        return $this->response;
    }*/

}