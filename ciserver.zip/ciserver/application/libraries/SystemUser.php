<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Description of SystemUser
 *
 * @author Virendra Jadeja
 */
class SystemUser {

    const SUPER_ADMIN = 1;
    const ADMIN = 3;
    const STUDENT = 4;
    const INSTITUTE_ADMIN = 5;
    const PARENT = 6;
    const AUTHOR = 8;
    const MARKETING = 9;
    const TEACHER = 10;
    const PARENT_FATHER = 11;
    const PARENT_MOTHER = 12;
    const PARENT_GARDIAN = 13;
    

    }
    ?>
