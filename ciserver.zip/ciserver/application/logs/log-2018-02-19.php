<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-19 11:31:14 --> Severity: Compile Error --> Cannot redeclare Login::users_post() D:\xampp\htdocs\ciserver\application\controllers\Login.php 38
