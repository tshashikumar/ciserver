<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-19 07:43:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\ciserver\system\core\Output.php 538
ERROR - 2018-04-19 09:02:46 --> Severity: error --> Exception: Call to undefined method CI_Input::put() D:\xampp\htdocs\ciserver\application\controllers\Login.php 43
